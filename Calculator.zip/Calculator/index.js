//get the input tag for the calculator display
let output = document.getElementById("display");

//when a button is pressed or clicked , show it on the input / display
function display(input){
    output.value += input
    // console.log(output.value)
}

//function to calculate when equal button is clicked
function calculate(){   
    //save what is on the display before calculation is done
    let original = output.value;
    //because js uses ** to calculate raise to power and not ^ i want to show ^ to the user but replace it with ** when i want to calculate
    let expression = original.replace(/\^/g, '**');
    //calculate whatever is inside the display and save it 
    let result = eval(expression);
    //display the result
    output.value = result;

    //creating a div element on the html to hold our history
    let entry = document.createElement("div");
    //the text content will be what was saved before calculating and the result after calculating
    entry.textContent = `${original} = ${result}`;
    //make the div created a child of the history div
    historyDiv.appendChild(entry);

    // get the history from localStorage update it and save it
    let history = JSON.parse(localStorage.getItem("calcHistory")) || [];
    history.push(`${original} = ${result}`);
    localStorage.setItem("calcHistory", JSON.stringify(history));
}

//to directly calculate for percentage
function percentCalc(){
    output.value = eval(output.value / 100);
}

//clear the display
function clearDisplay(){
    output.value = "";
}

//for the keyboard buttons. from the event object checks if the key pressed is needed for for calculation and then use it 
document.addEventListener("keydown", function(event){
    // console.log(event.key);
    const key = event.key;
    //check if it is a number or an operator
    if((key >= 0 && key <=9) || ['*', '/', '+', '-', '^', '.'].includes(key)){
        display(key);
        //make the enter key calculate too
    }else if(key === "Enter" || key === '='){
        //when i use my enter key i get some strange calculations sometimes so i googled it and saw that i could used this method to prevent any default attitude of the enter key 
        event.preventDefault();
        calculate()
        //remove the last thing that was entered with backspace
    }else if(key === "%"){
        percentCalc()
    }else if(key === "Backspace"){
        output.value = output.value.slice(0, -1);
        //clear display
    }else if(key === "Delete" || key === "Escape"){
        clearDisplay()
    }
});

//toogle between the calculator button and the history page
const toggleBtn = document.getElementById("hist");
const digitDiv = document.querySelector(".digits");
const historyDiv = document.getElementById("history");

// Load history from localStorage on page load
window.addEventListener("DOMContentLoaded", function() {
    let history = JSON.parse(localStorage.getItem("calcHistory")) || [];
    history.forEach(item => {
        let entry = document.createElement("div");
        entry.textContent = item;
        historyDiv.appendChild(entry);
    });
});

function clearHistory(){
    //clear the history div
    historyDiv.innerHTML = '';
    //Clear the local storage too
    localStorage.removeItem("calcHistory")
}

toggleBtn.addEventListener("click", function(){
    if(historyDiv.style.display === "block"){
        historyDiv.style.display = "none";
        digitDiv.style.display = "flex";
        toggleBtn.textContent = "History"
    }else {
        historyDiv.style.display = "block";
        digitDiv.style.display = "none";
        toggleBtn.textContent = "Back"
    }
})